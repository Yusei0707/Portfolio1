<html>
    <head>
        <meta charset = "utf-8">
        <title>セッション切れ</title>
        <link href = "stationerystore.css" rel = "stylesheet">
    </head>

    <body>
        <h1>Stationery Store</h1>

        <p>セッションの有効期限が切れました。</p>
        <form action="login.php" method="POST">
        <p>再度<button class="t_button">ログイン</button>してください。</p>
        </form>

    </body>